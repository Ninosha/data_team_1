# Guja

Project creates text file from object values given in uploaded json file.

Intstruction:
- Upload json file named "tasks.json"
- Json file should contain one object with key names: "file", "extension"
- If json file is empty txt file won't be created